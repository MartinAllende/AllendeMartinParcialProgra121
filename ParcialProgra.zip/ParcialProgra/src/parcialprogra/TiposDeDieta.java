
package parcialprogra;

public enum TiposDeDieta {
    HERBIVORO,
    CARNIVORO,
    OMNIVORO
}
