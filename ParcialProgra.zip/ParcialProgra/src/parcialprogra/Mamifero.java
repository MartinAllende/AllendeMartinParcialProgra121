
package parcialprogra;

public class Mamifero extends Animal implements Vacunacion{
    
    private float peso;
    private TiposDeDieta tipoDieta;
    
    public Mamifero(String nombre, int edad, float peso, TiposDeDieta tipoDieta)
    {
        super(nombre,edad);
        this.peso = peso;
        this.tipoDieta = tipoDieta;
    }
    
    public void vacunarAnimal()
    {
        System.out.println("Mamifero vacunado");
    }
    
    @Override
    public String toString()
    {
        return "Mamifero [peso = " + peso + ", tipo de dieta = " + tipoDieta + "]";
    }
    
}
