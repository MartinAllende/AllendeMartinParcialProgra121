
package parcialprogra;

import java.util.Objects;

public class Animal {
    
    private String nombre;
    private int edad;
    
    public Animal(String nombre, int edad)
    {
        this.nombre = nombre;
        this.edad = edad;
    }
    
    @Override
    public boolean equals(Object obj)
    {
        if(this == obj)
        {
            return true;
        }
        if(obj == null || getClass() != obj.getClass())
        {
            return false;
        }
        Animal a = (Animal)obj;
        
        return nombre.equals(a.nombre) && edad == a.edad;
    }
    
    @Override
    public int hashCode()
    {
        return Objects.hash(nombre,edad);
    }
}
