
package parcialprogra;

import java.util.ArrayList;

public class Zoologico {
    
    private ArrayList<Animal> animales;
    
    
    public Zoologico()
    {
        animales = new ArrayList<Animal>();
    }
    
    public void vacunarAnimales()
    {
        for(Animal animal : animales)
        {
            if(animal instanceof Ave ave)
            {
                ave.vacunarAnimal();
            }
            else if(animal instanceof Mamifero mamifero)
            {
                mamifero.vacunarAnimal();
            }
            else
            {
                System.out.println("no se puede vacunar un Reptil");
            }
        }
    }
    
    private boolean AnimalYaExistente(Animal animal)
    {
        for(Animal a : animales)
        {
            if(a.equals(animal))
            {
                return true;
            }
        }
        
        return false;
    }
    
    public void AgregarAnimal(Animal animal)
    {
        if(animal == null)
        {
            throw new NullPointerException();
        }
        else if(AnimalYaExistente(animal))
        {
            throw new AnimalYaExistenteException();
        }
        else
        {
            animales.add(animal);
        }
    }
    
    public void mostrarAnimales()
    {
        for(Animal a : animales)
        {
            System.out.println(a.toString());
        }
    }
    
}
