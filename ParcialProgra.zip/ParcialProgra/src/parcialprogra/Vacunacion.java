
package parcialprogra;

public interface Vacunacion {
    
    public void vacunarAnimal();
    
}
