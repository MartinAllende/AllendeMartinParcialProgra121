
package parcialprogra;

public class MainZoologico {

  
    public static void main(String[] args) 
    {
        
        Zoologico zoo = new Zoologico();
        try
        {
            zoo.AgregarAnimal(new Reptil("Juan",20,TiposRegulacionTemperatura.ECTOTERMICA, TiposDeEscama.AQUILLADA));
            zoo.AgregarAnimal(new Mamifero("Carlos",10,(float)30.4,TiposDeDieta.CARNIVORO));
            zoo.AgregarAnimal(new Ave("Pichon",5,(float)54.7));
            zoo.AgregarAnimal(new Reptil("Mimi",40,TiposRegulacionTemperatura.HIBERNACION, TiposDeEscama.AQUILLADA));
            zoo.AgregarAnimal(new Ave("Pajarito",5,(float)54.7));
            zoo.AgregarAnimal(new Reptil("Juan",20,TiposRegulacionTemperatura.HIBERNACION, TiposDeEscama.AQUILLADA));
        }
        catch(NullPointerException ex)
        {
            System.out.println("Me pasaste un null");
        }
        catch(AnimalYaExistenteException ex)
        {
            System.out.println(ex.getMessage());
        }
        
        zoo.vacunarAnimales();
        zoo.mostrarAnimales();
        
    }
    
}
