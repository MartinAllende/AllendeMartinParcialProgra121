
package parcialprogra;

public class Reptil extends Animal{
    
    private TiposRegulacionTemperatura regulacionTemperatura;
    private TiposDeEscama tipoEscama;
    
    public Reptil(String nombre, int edad, TiposRegulacionTemperatura regulacionTemperatura, TiposDeEscama tipoEscama)
    {
        super(nombre, edad);
        this.regulacionTemperatura = regulacionTemperatura;
        this.tipoEscama = tipoEscama;
    }
    
    @Override
    public String toString()
    {
        return "Reptil [tipo de escama = " + tipoEscama + ", tipo de regulacion de temperatura = " + regulacionTemperatura + "]";
    }
    
}
