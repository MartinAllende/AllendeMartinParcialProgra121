package parcialprogra;


public class AnimalYaExistenteException extends RuntimeException{
    
    private final static String MENSAJE = "Este animal ya existe";
    
    public AnimalYaExistenteException()
    {
        super(MENSAJE);
    }
    
}
