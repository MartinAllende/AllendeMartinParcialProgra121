
package parcialprogra;

public enum TiposRegulacionTemperatura {
    ECTOTERMICA,
    HIBERNACION
}
