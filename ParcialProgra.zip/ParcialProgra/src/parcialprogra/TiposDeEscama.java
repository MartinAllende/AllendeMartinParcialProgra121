
package parcialprogra;

public enum TiposDeEscama {
    QUERATINOSA,
    AQUILLADA
}
