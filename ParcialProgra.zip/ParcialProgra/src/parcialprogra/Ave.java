
package parcialprogra;

public class Ave extends Animal implements Vacunacion{
    
    private float envergaduraAlas;
    
    public Ave(String nombre, int edad, float envergaduraAlas)
    {
        super(nombre, edad);
        this.envergaduraAlas = envergaduraAlas;
    }
    
    public void vacunarAnimal()
    {
        System.out.println("Ave vacunada");
    }
    
    @Override
    public String toString()
    {
        return "Ave [ envergadura de alas = " + envergaduraAlas + "]";
    }
    
}
